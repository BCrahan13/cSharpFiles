class AnyLegalClassName
{
   static void Main()
   {
      /*********/;
   }
}

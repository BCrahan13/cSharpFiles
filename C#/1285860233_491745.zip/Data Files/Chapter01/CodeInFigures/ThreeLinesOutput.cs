using static System.Console;
class ThreeLinesOutput
{
   static void Main()
   {
      WriteLine("Line one");
      WriteLine("Line two");
      WriteLine("Line three");
   }
}


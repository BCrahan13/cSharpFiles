// Filename DebugOne1.cs
// This program outputs a nursey rhyme
class DebugOne1
{
   static void Main()
   {
      System.Console.WriteLine("Mary had a little lamb")
      System.Console.Writeline("Its fleece was white as snow")
      System.Console.writeLine("And everywhere that Mary went")
      System.console.WriteLine("The lamb was sure to go")
   }
}

// Filename DebugOne3.cs
// This program outputs directions to a party
using System
class DebugOne3
{
   static void Main()
   {
      WriteLine("Take Highway 51 north");
      Writeline("Exit at County Road H");
      WriteLine("Go three blocks and make a right on School Street");
      WriteLine("Go right at Elm").
      WriteLine("Party is four houses down on the left").
}

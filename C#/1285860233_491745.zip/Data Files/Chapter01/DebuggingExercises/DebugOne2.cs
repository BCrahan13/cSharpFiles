/ Filename DebugOne2.cs
/ This program outputs a large C#
using static System.Console;
class DebugOne2
{
   static void main()
   {
      WriteLine("CCCCC   #  #);
      WriteLine(C     ########");
      WriteLine("C       #  #);
      WriteLine("C     ########");
      WriteLine("CCCCC   #  #");
   }
}

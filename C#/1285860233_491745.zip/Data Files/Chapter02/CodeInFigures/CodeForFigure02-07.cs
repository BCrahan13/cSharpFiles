using static System.Console;
class CodeForFigure0207
{
   static void Main()
   {
      double someMoney = 439.75;
      WriteLine("I have ${0}. ${0}!! ${0}!!",
         someMoney);
   }
}

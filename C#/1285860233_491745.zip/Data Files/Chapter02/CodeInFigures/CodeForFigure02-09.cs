using static System.Console;
class CodeForFigure0209
{
   static void Main()
   {
      WriteLine("{0, 5}", 4);
      WriteLine("{0, 5}", 56);
      WriteLine("{0, 5}", 789);
      WriteLine("{0, -8}{1, -8}", "Richard", "Lee");
      WriteLine("{0, -8}{1, -8}", "Marcia", "Parker");
      WriteLine("{0, -8}{1, -8}", "Ed", "Tompkins");

   }
}

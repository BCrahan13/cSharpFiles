using static System.Console;
class DisplaySomeMoney2
{
   static void Main()
   {
      double someMoney = 39.45;
      Write("The money is $");
      WriteLine(someMoney);
   }
}
